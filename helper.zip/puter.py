from curl_cffi import requests

TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0IjoiYXUiLCJ2IjoiMC4wLjAiLCJ1dSI6IjdPa1dmellqVG1LZnFqVXU0Wm9oZ1E9PSIsImF1IjoiaWRnL2ZEMDdVTkdhSk5sNXpXUGZhUT09IiwicyI6IlZmQnJpbDZYT1hUUDU4Y08rV29Za0E9PSIsImlhdCI6MTc3MTM0ODgwNn0.qdZptjuahv5F0QAWft0QjcIvuJuUdO6qVq4C7WWnrA8"

def solve(image_url: str):
    prompt = (
            u"Bạn là một lập trình viên C++ kỳ cựu với kinh nghiệm thi đấu ICPC. "
            u"Trước khi viết code, hãy tìm kiếm trên internet để xác định xem đề bài này đã có "
            u"solution tối ưu hay chưa. Nếu có, hãy viết lại solution đó theo cách của bạn sao cho "
            u"logic vẫn giữ nguyên nhưng code khác biệt đáng kể so với solution gốc (thay đổi cách "
            u"đặt tên biến, cấu trúc code, thứ tự xử lý, v.v.). Nếu không tìm thấy solution, hãy tự "
            u"viết code C++98 tối ưu nhất để giải bài toán dưới đây, đảm bảo chạy dưới 1 giây cho "
            u"mọi test case. Vui lòng giải thích khi đưa code.\n"
            u"- Yêu cầu code:\n"
            u"+ Code không có comment.\n"
            u"+ Tuân thủ full C++98 syntax.\n"
            u"+ Dùng #include <bits/stdc++.h> để rút gọn code.\n"
            u"+ Nếu đề bài có cung cấp file input và file output (đuôi .INP và .OUT), "
            u"sử dụng freopen để đọc và xuất dữ liệu, còn không thì cứ dùng standard input và output.\n"
            u"+ Tối ưu nhập xuất (có thể dùng ios_base::sync_with_stdio(false); cin.tie(0)).\n"
            u"+ Xử lý mọi edge case, tránh tràn số (dùng long long khi cần, định nghĩa typedef/define cho ll).\n"
            u"+ Ưu tiên dùng mảng tĩnh hoặc vector thay vì cấu trúc phức tạp nếu không cần thiết.\n"
            u"+ Kết hợp typedef/define để rút gọn code (ví dụ: typedef vector<int> vi; \n"
            u"+ Không sử dụng các tính năng C++11+ như auto, nullptr, range-based for, initializer_list, lambda function, v.v.\n"
            u"+ Luôn trả về solution code nằm trong code snippet ('''cpp''').\n"
            u"Đề bài: "
        )
    
    headers = {
        'accept': '*/*',
        'authorization': TOKEN,
        'content-type': 'application/json;charset=UTF-8',
        'origin': 'https://docs.puter.com',
        'referer': 'https://docs.puter.com/',
    }
    
    json_data = {
        "interface": "puter-chat-completion",
        "driver": "ai-chat",
        "test_mode": True,
        "method": "complete",
        "args": {
            "vision": True,
            "messages": [
                {
                    "content": [
                        prompt,
                        {
                            "image_url": {
                                "url": image_url
                            }
                        }
                    ]
                }
            ],
            'model': 'gemini-3-pro-preview',
            'temperature': 0.2
        },
    }
    
    response = requests.post('https://api.puter.com/drivers/call', headers=headers, json=json_data, impersonate="chrome", timeout=None)
    try:
        res = response.json()["result"]["message"]["content"]
        start_idx = res.rfind("```cpp")
        end_idx = res.rfind("}\n```")  
        if start_idx == -1 or end_idx == -1:
            return res  
        return res[start_idx + 7 : end_idx + 1]  
    except:
        return response.text

print(solve("https://scontent.fsgn2-7.fna.fbcdn.net/v/t39.30808-6/634935583_3673257196145065_9215238907766164526_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=833d8c&_nc_ohc=1zDGelBd3PsQ7kNvwFsu4Mg&_nc_oc=AdnUvilrNd3u7D8fhAJke41e6i9J--njKYQQX8av12_e5R4S4N9dZ8Aj3geQMs-rc7uj7rrKTJX2EqxQBZ08h2xP&_nc_zt=23&_nc_ht=scontent.fsgn2-7.fna&_nc_gid=y-J4gHQgZrZAVT1q8XNoEg&oh=00_Afv-qRSYxpQ9SKS7DdFtuNP6FWPpdojL7I1Mnmrj5IDA8g&oe=699A7DE1"))